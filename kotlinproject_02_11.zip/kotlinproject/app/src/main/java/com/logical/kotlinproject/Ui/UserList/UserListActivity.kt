package com.logical.kotlinproject.Ui.UserList

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.logical.kotlinproject.Adapter.UserHomeVendorAdapter
import com.logical.kotlinproject.DTO.MainList
import com.logical.kotlinproject.Database.User
import com.logical.kotlinproject.Database.UserDao
import com.logical.kotlinproject.Database.UserDataBase
import com.logical.kotlinproject.R
import com.logical.kotlinproject.databinding.ActivityUserListBinding

class UserListActivity : AppCompatActivity() {
     lateinit var binding:ActivityUserListBinding
    lateinit var db: UserDataBase
    lateinit var dao: UserDao
    lateinit var list: List<User>
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
         binding= ActivityUserListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = UserDataBase.getDatabase(this)

        dao = db.userDao()
        list = dao.getAllUsers()
        val layoutManager = LinearLayoutManager(applicationContext)
        val userm = UserListAdapter(
            list, applicationContext
        )
        binding.recycleView.layoutManager = layoutManager
        binding.recycleView.adapter = userm
    }
}