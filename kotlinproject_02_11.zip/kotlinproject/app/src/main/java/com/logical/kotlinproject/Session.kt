package com.logical.kotlinproject

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import com.logical.kotlinproject.Ui.MainActivity


class Session(private val _context: Context) : Any() {
    private val Rapidine_pref: SharedPreferences =
        _context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    private val editor: SharedPreferences.Editor = Rapidine_pref.edit()
    fun setMobile(mobile: String?, email: String?) {
        editor.putString(Mobile, mobile)
        editor.putString(Email, email)
        editor.apply()
        editor.commit()
    }


    fun get_FormStatus(): String? {
        return Rapidine_pref.getString(FormStatus, "")
    }

    fun set_FormStatus(fm: String?) {
        editor.putString(FormStatus, fm)
        editor.apply()
        editor.commit()
    }

    fun getUserId(): String? {
        return Rapidine_pref.getString(UserId, "")
    }

    fun setUserId(fm: String?) {
        editor.putString(UserId, fm)
        editor.apply()
        editor.commit()
    }


    val email: String?
        get() = Rapidine_pref.getString(Email, "")

    fun logout() {
        editor.clear()
        editor.apply()
        val showLogin = Intent(_context, MainActivity::class.java)
        showLogin.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK)
        showLogin.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        _context.startActivity(showLogin)
    }

    fun setLogin(isLoggedIn: Boolean) {
        editor.putBoolean(IS_LOGGEDIN, isLoggedIn)
        editor.commit()
    }


    companion object {
        private val TAG = Session::class.java.simpleName
        private const val PREF_NAME = "Rapidine_pref2"
        private const val IS_LOGGEDIN = "isLoggedIn"
        private const val FormStatus = "formstatus"
        private const val Mobile = "mobile"
        private const val Email = "email"
        private const val UserId = "user_id"


    }

    init {
        editor.apply()
    }
}
