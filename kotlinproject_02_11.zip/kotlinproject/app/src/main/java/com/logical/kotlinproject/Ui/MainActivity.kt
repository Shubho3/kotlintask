package com.logical.kotlinproject.Ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.os.SystemClock.currentGnssTimeClock
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.logical.kotlinproject.API.ApiClient
import com.logical.kotlinproject.API.ApiService
import com.logical.kotlinproject.Adapter.UserHomeVendorAdapter
import com.logical.kotlinproject.DTO.MainList
import com.logical.kotlinproject.OnClick
import com.logical.kotlinproject.Session
import com.logical.kotlinproject.databinding.ActivityMainBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity(), OnClick {
    private lateinit var binding: ActivityMainBinding
     private lateinit var session:Session
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
        session= Session(applicationContext)
        binding.text.setText(session.getUserId())
        binding.text.setOnClickListener {
            Toast.makeText(applicationContext, "Refresh ", Toast.LENGTH_SHORT).show()
            getData();

        }
    }

    private fun getData2() {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://logicaltest.website/praveen/camera/Api_new/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
        val service = retrofit.create(ApiService::class.java)
        val call: Call<MainList> = service.getAppUser("3")
        //Toast.makeText(applicationContext, "hit",Toast.LENGTH_SHORT).show()

        call.enqueue(object : Callback<MainList> {
            override fun onResponse(call: Call<MainList>, response: Response<MainList>) {


                if (response.body() != null) {
                    val weatherResponse = response.body()!!
                    Toast.makeText(
                        applicationContext,
                        weatherResponse.getResult(),
                        Toast.LENGTH_SHORT
                    ).show()
                    val list: List<MainList.Datum> = response.body()!!.getData()
                    val layoutManager = LinearLayoutManager(applicationContext)
                    val homeVendorAdapter = UserHomeVendorAdapter(
                        list, applicationContext, this@MainActivity
                    )
                    binding.recycleView.layoutManager = layoutManager
                    binding.recycleView.adapter = homeVendorAdapter
                }
            }

            override fun onFailure(call: Call<MainList>, t: Throwable) {
                Toast.makeText(applicationContext, "failed", Toast.LENGTH_SHORT).show()

            }
        })
    }

    private fun getData() {
        binding.progressCircular.isVisible= true
        val retrofit = ApiClient.getClient()
        val userApi = retrofit.create(ApiService::class.java)
        val call: Call<MainList> = userApi.getAppUser("3")
        //Toast.makeText(applicationContext, "hit",Toast.LENGTH_SHORT).show()
        call.enqueue(object : Callback<MainList> {
            override fun onResponse(call: Call<MainList>, response: Response<MainList>) {
                if (response.body() != null) {

                  //  val weatherResponse = response.body()!!
                    Log.e("TAG", "response 33: " + Gson().toJson(response.body()))
                    /* Toast.makeText(
                         applicationContext,
                         weatherResponse.getResult(),
                         Toast.LENGTH_SHORT
                     ).show()*/
                    if (response.body()!!.getResult().equals("true", ignoreCase = true)) {
                        val list: List<MainList.Datum> = response.body()!!.getData()
                        val layoutManager = LinearLayoutManager(applicationContext)
                        val homeVendorAdapter =
                            UserHomeVendorAdapter(list, applicationContext, this@MainActivity)
                        binding.recycleView.layoutManager = layoutManager
                        binding.recycleView.adapter = homeVendorAdapter
                        binding.progressCircular.isVisible= false
                        session.setUserId(""+list.size)

                        binding.text.setText(session.getUserId())

                    }else{
                        binding.progressCircular.isVisible= false

                    }
                }
                else{
                    binding.progressCircular.isVisible= false

                }
            }

            override fun onFailure(call: Call<MainList>, t: Throwable) {
                Toast.makeText(applicationContext, "failed", Toast.LENGTH_SHORT).show()
                binding.progressCircular.isVisible= false

            }
        })
    }

    override fun onClick(onclick: String, value: String) {

        val intent = Intent(this, UserDetails::class.java)
        startActivity(intent)
    }

}





