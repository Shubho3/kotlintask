package com.logical.kotlinproject.API

import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

  object  ApiClient {
    val okHttpClient = OkHttpClient()
        .newBuilder()
        .addInterceptor(RequestInterceptor)
        .build()
    fun getClient(): Retrofit =
        Retrofit.Builder()
            .client(okHttpClient)
            .baseUrl("https://logicaltest.website/praveen/camera/Api_new/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

}