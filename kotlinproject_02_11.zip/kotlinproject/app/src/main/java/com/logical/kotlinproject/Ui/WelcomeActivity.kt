package com.logical.kotlinproject.Ui

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.deishelon.roundedbottomsheet.RoundedBottomSheetDialog
import com.logical.kotlinproject.Database.User
import com.logical.kotlinproject.Database.UserDao
import com.logical.kotlinproject.Database.UserDataBase
import com.logical.kotlinproject.R
import com.logical.kotlinproject.Ui.UserList.UserListActivity
import com.logical.kotlinproject.databinding.ActivityWelcomeBinding

class WelcomeActivity : AppCompatActivity() {
    lateinit var binding: ActivityWelcomeBinding
    lateinit var db: UserDataBase
    lateinit var dao: UserDao
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = UserDataBase.getDatabase(this)
        dao = db.userDao()
        binding.dislikeLiner.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        binding.dislikeLiner3.setOnClickListener {
            val intent = Intent(this, UserListActivity::class.java)
            startActivity(intent)
        }

        binding.dislikeLiner2.setOnClickListener {
            val mBottomSheetDialog = RoundedBottomSheetDialog(this@WelcomeActivity)
            val sheetView = layoutInflater.inflate(R.layout.dialog_2_my_rounded_bottom_sheet, null)
            mBottomSheetDialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            mBottomSheetDialog.setContentView(sheetView)
            val Ag_no = mBottomSheetDialog.findViewById<EditText>(R.id.edt_mobile)
            val Ag_pass = mBottomSheetDialog.findViewById<EditText>(R.id.edt_pass)
            val Ag_login = mBottomSheetDialog.findViewById<Button>(R.id.login_btn)
            val signup_btn = mBottomSheetDialog.findViewById<TextView>(R.id.signup_btn)
            signup_btn!!.setOnClickListener{
                val intent = Intent(this, SignupActivity::class.java)
                startActivity(intent)
            }
            Ag_login!!.setOnClickListener {
                Log.e("login", "onCreate: " + "login")
                if (Ag_no!!.text.contentEquals("", ignoreCase = true)) {
                    Toast.makeText(
                        applicationContext,
                        "Please Enter Phone No",
                        Toast.LENGTH_SHORT
                    ).show()

                } else if (Ag_pass!!.text.contentEquals("", ignoreCase = true)) {
                    Toast.makeText(
                        applicationContext,
                        "Please Enter Password",
                        Toast.LENGTH_SHORT
                    ).show()

                } else {
                    loginUser(
                        mBottomSheetDialog,
                        Ag_no.text.trim().toString(),
                        Ag_pass.text.trim().toString()
                    );
                }
            }
            mBottomSheetDialog.show()

        }
    }

    private fun loginUser(sheet: RoundedBottomSheetDialog, phone: String, pass: String) {
        var user: User
      //  user = dao.loadUser(phone, pass)!!
      //  if (user.phone.contentEquals(phone, true)) {
          /*  if (user.password.contentEquals(phone, true)) {*/
                sheet.dismiss()
                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
          /* } else {
                Toast.makeText(
                    applicationContext,
                    "Wrong Password",
                    Toast.LENGTH_SHORT
                ).show()
            }*/

      //  }

    }
}