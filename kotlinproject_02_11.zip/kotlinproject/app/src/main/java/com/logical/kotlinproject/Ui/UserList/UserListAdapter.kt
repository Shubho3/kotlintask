package com.logical.kotlinproject.Ui.UserList
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.logical.kotlinproject.DTO.MainList
import com.logical.kotlinproject.Database.User
import com.logical.kotlinproject.OnClick
import com.logical.kotlinproject.databinding.MainItemBinding

class UserListAdapter (

        var list: List<User>, var context: Context
    ) : RecyclerView.Adapter<UserListAdapter
    .ViewHolder>() {

        inner class ViewHolder(val binding: MainItemBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = MainItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(binding)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            with(holder) {
                with(list[position]) {
                    binding.AGRestaurentname.text = this.name
                    binding.awayTxt.text = this.phone
                    Glide.with(context)
                        .load("https://logicaltest.website/praveen/camera/assets/images/users/" + this.password)
                        .into(binding.image)
                    binding.image.setOnClickListener {
                    }
                }
            }
        }

        override fun getItemCount(): Int {
            return list.size
        }
    }
