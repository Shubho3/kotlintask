package com.logical.kotlinproject.DTO

import com.google.gson.annotations.Expose
import com.google.gson.annotations.SerializedName

class MainList {
    @SerializedName("result")
    @Expose
    private var result: String? = null
    @SerializedName("msg")
    @Expose
    private var msg: String? = null

    @SerializedName("path")
    @Expose
    private var path: String? = null

    @SerializedName("data")
    @Expose
    private var data: List<Datum> = emptyList()

    fun getResult(): String? {
        return result
    }

    fun setResult(result: String?) {
        this.result = result
    }

    fun getMsg(): String? {
        return msg
    }

    fun setMsg(msg: String?) {
        this.msg = msg
    }

    fun getPath(): String? {
        return path
    }

    fun setPath(path: String?) {
        this.path = path
    }

    fun getData(): List<Datum>{
        return data
    }

    fun setData(data: List<Datum>) {
        this.data = data
    }

    class Datum {
        @SerializedName("id")
        @Expose
        var id: String? = null

        @SerializedName("brand_name")
        @Expose
        var brandName: String? = null

        @SerializedName("city_name")
        @Expose
        var city: String? = null

        @SerializedName("image")
        @Expose
        var image: String? = null

        @SerializedName("like_status")
        @Expose
        var like_status: String? = null

        @SerializedName("hashtag_list")
        @Expose
        var hashtagList: List<Hashtag>? = null

        inner class Hashtag {
            @SerializedName("hashtag_name")
            @Expose
            var hashtagName: String? = null
        }
    }


}