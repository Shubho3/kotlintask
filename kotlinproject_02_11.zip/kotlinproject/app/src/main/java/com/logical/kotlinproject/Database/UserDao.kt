package com.logical.kotlinproject.Database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
  interface UserDao {

    @Query("SELECT id FROM user")
     fun getAllUsers(): MutableList<User>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
     fun insert(word: User)

 /*   @Query("DELETE FROM user")
     fun deleteAll(): Int*/


   /* @Query("SELECT * FROM user WHERE phone LIKE :userName")
     fun getUsername(userName: String): User?*/
}