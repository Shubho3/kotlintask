package com.logical.kotlinproject

interface OnClick {
    fun onClick(onclick: String, value: String)
}