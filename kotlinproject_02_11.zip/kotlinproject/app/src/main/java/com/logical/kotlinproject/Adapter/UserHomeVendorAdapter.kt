package com.logical.kotlinproject.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.logical.kotlinproject.DTO.MainList
import com.logical.kotlinproject.OnClick
import com.logical.kotlinproject.databinding.MainItemBinding

public class UserHomeVendorAdapter(

    var list: List<MainList.Datum>, var context: Context, var onClick: OnClick
) : RecyclerView.Adapter<UserHomeVendorAdapter
.ViewHolder>() {

    inner class ViewHolder(val binding: MainItemBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = MainItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        with(holder) {
            with(list[position]) {
                binding.AGRestaurentname.text = this.brandName
                binding.awayTxt.text = this.city
                Glide.with(context)
                    .load("https://logicaltest.website/praveen/camera/assets/images/users/" + this.image)
                    .into(binding.image)
                binding.image.setOnClickListener {
                    onClick.onClick("", "")
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }
}