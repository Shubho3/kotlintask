package com.logical.kotlinproject.Ui.UserList

import android.content.Context
import com.logical.kotlinproject.Database.User
import com.logical.kotlinproject.Database.UserDao
import com.logical.kotlinproject.Database.UserDataBase

class UserListRepositary(var context: Context) {
     var db: UserDataBase= UserDataBase.getDatabase(context)
     var dao: UserDao=db.userDao()
   var user:List<User> = dao.getAlphabetizedWords()


}