package com.logical.kotlinproject.Ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.logical.kotlinproject.R
import com.logical.kotlinproject.databinding.ActivityUserDetailsBinding

class UserDetails : AppCompatActivity() {
     private lateinit var binding: ActivityUserDetailsBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityUserDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}