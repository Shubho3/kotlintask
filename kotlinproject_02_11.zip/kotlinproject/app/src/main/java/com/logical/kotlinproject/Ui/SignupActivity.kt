package com.logical.kotlinproject.Ui

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import com.logical.kotlinproject.Database.User
import com.logical.kotlinproject.Database.UserDao
import com.logical.kotlinproject.Database.UserDataBase
import com.logical.kotlinproject.databinding.ActivitySignupBinding

class SignupActivity : AppCompatActivity() {
    lateinit var binding: ActivitySignupBinding
    lateinit var db: UserDataBase
    lateinit var dao: UserDao
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySignupBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = UserDataBase.getDatabase(this)

        dao = db.userDao()
        binding.loginBtn.setOnClickListener {
            Log.e("login", "onCreate: " + "login")

            if (binding.edtName.text.contentEquals("", ignoreCase = true)) {
                Toast.makeText(
                    applicationContext,
                    "Please Enter Name ",
                    Toast.LENGTH_SHORT
                ).show()

            } else if (binding.edtMobile.text.contentEquals("", ignoreCase = true)) {
                Toast.makeText(
                    applicationContext,
                    "Please Enter Phone No",
                    Toast.LENGTH_SHORT
                ).show()

            } else if (binding.edtPass.text.contentEquals("", ignoreCase = true)) {
                Toast.makeText(
                    applicationContext,
                    "Please Enter Password",
                    Toast.LENGTH_SHORT
                ).show()

            } else {
                SignupUser(
                    binding.edtName.text.trim().toString(),
                    binding.edtMobile.text.trim().toString(),
                    binding.edtPass.text.trim().toString()
                );
            }
        }
    }


     fun SignupUser(name: String, mobile: String, pass: String) {
       // var user: User
      /*  user = dao.loadUser(mobile, pass)!!
        if (user.phone.contentEquals(mobile, ignoreCase = true)) {
            Toast.makeText(
                applicationContext,
                "Phone NO Already Exists",
                Toast.LENGTH_SHORT
            ).show()

        } else {*/
          dao.insert(User(0,name ,pass, mobile))
            Toast.makeText(
                applicationContext,
                "User Created Successfully  ---  "+dao.getAlphabetizedWords().size,
                Toast.LENGTH_SHORT
            ).show()

      //  }
    }

}
